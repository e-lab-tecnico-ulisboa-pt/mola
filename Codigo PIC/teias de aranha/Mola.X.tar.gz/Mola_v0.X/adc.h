#ifndef ADC_H
#define	ADC_H

extern void init_ADC(void);

#endif	/* ADC_H */

