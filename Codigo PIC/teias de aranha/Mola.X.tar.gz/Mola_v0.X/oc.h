#ifndef OC_H
#define	OC_H

extern void init_OC2(void);
extern void init_OC4(void);

#endif	/* OC_H */

