#ifndef DELAYS_H
#define	DELAYS_H

extern void delay_ms(unsigned int delay);


#endif	/* DELAYS_H */

